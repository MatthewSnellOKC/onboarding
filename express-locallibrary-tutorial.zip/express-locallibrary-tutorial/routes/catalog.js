var express = require('express');
var router = express.Router();


// Require our controllers
var candidate_controller = require('../controllers/candidateController');

// /* GET catalog home page. */
router.get('/', candidate_controller.index);  

/// GENRE ROUTES ///

/* GET request for creating a Genre. NOTE This must come before route that displays Genre (uses id) */
router.get('/candidate/create', candidate_controller.candidate_create_get);

/* POST request for creating Genre. */
router.post('/candidate/create', candidate_controller.candidate_create_post);

/* GET request to delete Genre. */
router.get('/candidate/:id/delete', candidate_controller.candidate_delete_get);

// POST request to delete Genre
router.post('/candidate/:id/delete', candidate_controller.candidate_delete_post);

/* GET request to update Genre. */
router.get('/candidate/:id/update', candidate_controller.candidate_update_get);

// POST request to update Genre
router.post('/candidate/:id/update', candidate_controller.candidate_update_post);

/* GET request for one Genre. */
router.get('/candidate/:id', candidate_controller.candidate_detail);

/* GET request for list of all Genre. */
router.get('/candidates', candidate_controller.candidate_list);


module.exports = router;
